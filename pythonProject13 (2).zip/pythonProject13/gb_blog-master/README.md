# gb_blog
Блог, который ещё дорабатывать и дорабатывать...

Оно, кстати, в github pages умеет: https://ronmount.github.io/gb_blog/
